package mpi.aida.config.settings;


public class EntityLookupSettings {
  public static enum LOOKUP_SOURCE {
    DATABASE, DICTIONARY
  }
}
