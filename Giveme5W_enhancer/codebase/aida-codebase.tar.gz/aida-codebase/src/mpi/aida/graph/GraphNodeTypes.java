package mpi.aida.graph;

public enum GraphNodeTypes {
	MENTION, ENTITY
}
