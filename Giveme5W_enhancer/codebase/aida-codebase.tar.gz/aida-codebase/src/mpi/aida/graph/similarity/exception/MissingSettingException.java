package mpi.aida.graph.similarity.exception;


public class MissingSettingException extends Exception {

  public MissingSettingException(String string) {
    super(string);
  }

  /**
   * 
   */
  private static final long serialVersionUID = -1610134821236307372L;

}
