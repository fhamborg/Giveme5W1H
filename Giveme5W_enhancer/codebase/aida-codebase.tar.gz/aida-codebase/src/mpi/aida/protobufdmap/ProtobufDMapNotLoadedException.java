package mpi.aida.protobufdmap;

public class ProtobufDMapNotLoadedException extends ProtobufDMapException {
  public ProtobufDMapNotLoadedException(String msg) {
    super(msg);
  }

  public ProtobufDMapNotLoadedException() {
  }
}
