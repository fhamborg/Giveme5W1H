package mpi.aida.util;

import java.util.ArrayList;
import java.util.List;

public class MinCover {
	public int length;
	public List<Integer> startPositions =  new ArrayList<Integer>();
	public List<Integer> endPositions =  new ArrayList<Integer>();
}
