package mpi.aida.util;


public enum YagoVersion {

    YAGO2, YAGO3
}
