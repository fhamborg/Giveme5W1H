package mpi.aida.util.normalization;


public interface TextNormalizer {
  
  public String normalize(String input);

}
