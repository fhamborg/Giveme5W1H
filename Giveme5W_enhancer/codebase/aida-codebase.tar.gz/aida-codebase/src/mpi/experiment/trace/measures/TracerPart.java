package mpi.experiment.trace.measures;


public abstract class TracerPart {
  public abstract String getOutput();
}
