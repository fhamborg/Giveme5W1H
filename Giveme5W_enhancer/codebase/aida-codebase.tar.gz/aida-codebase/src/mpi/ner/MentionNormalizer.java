package mpi.ner;


public interface MentionNormalizer {
  
  public String normalize(String mention);

}
