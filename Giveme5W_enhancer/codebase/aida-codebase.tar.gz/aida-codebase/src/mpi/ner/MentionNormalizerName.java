package mpi.ner;


public enum MentionNormalizerName {
  WhiteSpaceNormalizer
}
