package mpi.ner;

public enum NERTaggerName {
	StanfordNER, StanfordNERWhiteSpaceTokenizer, DICTIONARY, StanfordPOS, LingPipeNER, LingPipePOS, OpenNLPNER, OpenNLPPOS, DEXTER, BOLDYREV
}
